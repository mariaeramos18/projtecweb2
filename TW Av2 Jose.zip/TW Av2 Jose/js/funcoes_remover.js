function handleLimparTodoOEstoque() {
    if (confirm("ATENÇÃO: Tem certeza que deseja limpar TODO o estoque? Esta ação é irreversível e removerá todos os calçados!")) {
        estoque.limparTodoEstoque();
        alert("Estoque limpo com sucesso!");
        exibirTodosCalcados();
    }
}
function removerQuantidadeDoCalcado(codigo) {
    const qtdeStr = prompt(`Quantos itens deseja remover do calçado ${codigo}?`);
    const qtde = Number(qtdeStr);
    if (isNaN(qtde) || qtde <= 0) {
        alert("Quantidade inválida.");
        return;
    }
    try {
        estoque.removerQuantidadeDoEstoque(codigo, qtde);
        alert(`Nova quantidade para ${codigo}: ${estoque.consultarCalcadoPorCodigo(codigo).quantidade}`); // Mostra a nova quantidade
        
        exibirTodosCalcados();
    } catch (error) {
        alert("Erro: " + error.message);
    }
}

function removerCalcadoDoEstoque(codigo) {
    if (confirm(`Tem certeza que deseja remover o calçado com código "${codigo}"?`)) {
        try {
            if (estoque.removerCalcado(codigo)) {
                alert(`Calçado "${codigo}" removido com sucesso.`);
            } else {
                alert(`Calçado "${codigo}" não encontrado.`);
            }
            exibirTodosCalcados();
        } catch (error) {
            alert("Erro ao remover calçado: " + error.message);
        }
    }
}