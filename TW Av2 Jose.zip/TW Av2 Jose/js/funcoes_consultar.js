/**
 * Funções para CONSULTA e exibição de calçados.
 * Depende da instância global 'estoque' (definida em main.js).
 */

function handleConsultarCalcadoEExibir() {
    const codigo = prompt("Digite o CÓDIGO do calçado para consultar:");
    if (!codigo) return;

    const calcado = estoque.consultarCalcadoPorCodigo(codigo);
    const resultadosDiv = document.getElementById('resultadosConsulta');
    resultadosDiv.innerHTML = ''; // Limpa resultados anteriores

    if (calcado) {
        resultadosDiv.innerHTML += `
            <h3>Detalhes do Calçado: ${calcado.codigo}</h3>
            <p><strong>Modelo:</strong> ${calcado.modelo}</p>
            <p><strong>Cor:</strong> ${calcado.cor}</p>
            <p><strong>Tamanho:</strong> ${calcado.tamanho}</p>
            <p><strong>Quantidade:</strong> ${calcado.quantidade}</p>
        `;
    } else {
        resultadosDiv.innerHTML = `<p style="color: orange;">Calçado com código "${codigo}" não encontrado no estoque.</p>`;
    }
}

// Esta função é chamada por outras funções (como após adicionar/remover)
// e também pela main.js ao carregar a seção de gestão.
function exibirTodosCalcados() {
    const listaDiv = document.getElementById('listaDeCalcados');
    listaDiv.innerHTML = ''; // Limpa a lista atual

    const todos = estoque.obterTodosCalcados();

    if (todos.length > 0) {
        listaDiv.innerHTML = '<h2>Calçados no Estoque:</h2>';
        todos.forEach(calcado => {
            listaDiv.innerHTML += `
                <div style="border: 1px solid #ccc; padding: 10px; margin-bottom: 10px; border-radius: 5px;">
                    <p><strong>Código:</strong> ${calcado.codigo}</p>
                    <p><strong>Modelo:</strong> ${calcado.modelo}</p>
                    <p><strong>Cor:</strong> ${calcado.cor}</p>
                    <p><strong>Tamanho:</strong> ${calcado.tamanho}</p>
                    <p><strong>Quantidade:</strong> ${calcado.quantidade}</p>
                    <button onclick="adicionarQuantidadeAoCalcado('${calcado.codigo}')" style="margin-right: 5px;">Adicionar Qtd</button>
                    <button onclick="removerQuantidadeDoCalcado('${calcado.codigo}')" style="margin-right: 5px;">Remover Qtd</button>
                    <button onclick="removerCalcadoDoEstoque('${calcado.codigo}')" style="background-color: #dc3545; color: white;">Remover Calçado</button>
                </div>
            `;
        });
    } else {
        listaDiv.innerHTML = '<p>Nenhum calçado cadastrado no estoque.</p>';
    }
}