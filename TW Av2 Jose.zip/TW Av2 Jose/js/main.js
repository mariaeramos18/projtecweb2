class Calcado {
    constructor(codigo, modelo, cor, tamanho, quantidade) {
        this.codigo = codigo || '';           
        this.modelo = modelo || '';           
        this.cor = cor || '';                 
        this.tamanho = Number(tamanho) || 0;  
        this.quantidade = Number(quantidade) || 0;
    }

    adicionarQuantidade(qtde) {
        qtde = Number(qtde);
        if (isNaN(qtde) || qtde <= 0) {
            throw new Error('Quantidade inválida para adição.');
        }
        this.quantidade += qtde;
        return this.quantidade;
    }

    removerQuantidade(qtde) {
        qtde = Number(qtde);
        if (isNaN(qtde)) {
            throw new Error('Quantidade inválida para remoção.');
        }
        if (qtde <= 0) {
            throw new Error('Quantidade deve ser positiva.');
        }
        if (this.quantidade - qtde < 0) {
            throw new Error('Quantidade insuficiente em estoque.');
        }
        this.quantidade -= qtde;
        return this.quantidade;
    }
}

// --- Classe EstoqueDeCalcados ---
class EstoqueDeCalcados {
    constructor() {
        this.calcados = this._carregarTodosCalcados();
    }

    adicionarCalcado(codigo, modelo, cor, tamanho, quantidade) {
        if (!codigo || !modelo || !cor || isNaN(tamanho) || isNaN(quantidade) || quantidade < 0) {
            throw new Error('Por favor, preencha todos os campos corretamente para adicionar um calçado.');
        }
        if (this.calcados.some(c => c.codigo === codigo)) {
            throw new Error(`Já existe um calçado com o código "${codigo}". Use um código diferente ou atualize o existente.`);
        }
        const novoCalcado = new Calcado(codigo, modelo, cor, tamanho, quantidade);
        this.calcados.push(novoCalcado);
        this._salvarTodosCalcados();
        return novoCalcado;
    }

    atualizarOuAdicionarCalcado(codigo, modelo, cor, tamanho, quantidade) {
        let calcadoExistente = this.calcados.find(c => c.codigo === codigo);
        if (calcadoExistente) {
            calcadoExistente.modelo = modelo;
            calcadoExistente.cor = cor;
            calcadoExistente.tamanho = Number(tamanho);
            calcadoExistente.quantidade = Number(quantidade);
        } else {
            calcadoExistente = new Calcado(codigo, modelo, cor, tamanho, quantidade);
            this.calcados.push(calcadoExistente);
        }
        this._salvarTodosCalcados();
        return calcadoExistente;
    }

    adicionarQuantidadeAoEstoque(codigo, qtde) {
        const calcado = this.calcados.find(c => c.codigo === codigo);
        if (!calcado) {
            throw new Error(`Calçado com código "${codigo}" não encontrado no estoque.`);
        }
        const novaQuantidade = calcado.adicionarQuantidade(qtde);
        this._salvarTodosCalcados();
        return novaQuantidade;
    }

    removerQuantidadeDoEstoque(codigo, qtde) {
        const calcado = this.calcados.find(c => c.codigo === codigo);
        if (!calcado) {
            throw new Error(`Calçado com código "${codigo}" não encontrado no estoque.`);
        }
        const novaQuantidade = calcado.removerQuantidade(qtde);
        this._salvarTodosCalcados();
        return novaQuantidade;
    }

    removerCalcado(codigo) {
        const initialLength = this.calcados.length;
        this.calcados = this.calcados.filter(c => c.codigo !== codigo);
        if (this.calcados.length < initialLength) {
            this._salvarTodosCalcados();
            return true;
        }
        return false;
    }

    consultarCalcadoPorCodigo(codigo) {
        return this.calcados.find(c => c.codigo === codigo);
    }

    obterTodosCalcados() {
        return [...this.calcados];
    }

    limparTodoEstoque() {
        this.calcados = [];
        sessionStorage.removeItem('estoqueCalcados');
        // Remover chaves antigas, caso persistam de versões anteriores
        sessionStorage.removeItem('calcado');
        sessionStorage.removeItem('calcado_codigo');
        sessionStorage.removeItem('calcado_modelo');
        sessionStorage.removeItem('calcado_cor');
        sessionStorage.removeItem('calcado_tamanho');
        sessionStorage.removeItem('calcado_quantidade');
    }

    _salvarTodosCalcados() {
        sessionStorage.setItem('estoqueCalcados', JSON.stringify(this.calcados));
    }

    _carregarTodosCalcados() {
        const dadosSalvos = sessionStorage.getItem('estoqueCalcados');
        if (dadosSalvos) {
            const arrayRaw = JSON.parse(dadosSalvos);
            // CORREÇÃO: Ordem dos parâmetros no construtor Calcado
            return arrayRaw.map(item => new Calcado(item.codigo, item.modelo, item.cor, item.tamanho, item.quantidade)); 
        }
        return [];
    }
}

// --- Funções de Interface (Login, Logout e Encerrar) ---
const estoque = new EstoqueDeCalcados();
function showLoginSection() {
    document.getElementById('loginSection').classList.remove('hidden');
    document.getElementById('managementSection').classList.add('hidden');
    document.getElementById('txtEmail').value = '';
    document.getElementById('txtSenha').value = '';
    document.getElementById('txtMensagem').innerHTML = '';
}

function showManagementSection() {
    document.getElementById('loginSection').classList.add('hidden');
    document.getElementById('managementSection').classList.remove('hidden');
    if (typeof exibirTodosCalcados === 'function') {
        exibirTodosCalcados(); 
    }
}

function login() {
    const email = document.getElementById('txtEmail').value;
    const senha = document.getElementById('txtSenha').value;
    const msg = document.getElementById('txtMensagem');


    console.log("Email digitado:", email);
    console.log("Senha digitada:", senha);
    console.log("Email esperado:", 'teste.com.br');
    console.log("Senha esperada:", 'teste');
    console.log("Comparação de Email é IGUAL?", email === 'teste.com.br');
    console.log("Comparação de Senha é IGUAL?", senha === 'teste');


    if (email === 'teste.com.br' && senha === 'teste') {
        sessionStorage.setItem('loggedIn', 'true'); 
        showManagementSection(); 
    } else {
        msg.innerHTML = 'E-mail ou senha incorretos';
        document.getElementById('txtEmail').focus(); 
    }
}

function logout() {
    if (confirm("Deseja realmente sair do sistema de gestão?")) {
        sessionStorage.removeItem('loggedIn'); 
        showLoginSection(); 
    }
}

function encerrar() {
    window.location.href = 'encerrar.html'; 
}

// --- Inicialização da Aplicação ---
document.addEventListener('DOMContentLoaded', () => {

    if (sessionStorage.getItem('loggedIn') === 'true') {
        showManagementSection();
    } else {
        showLoginSection(); 
    }
});