
function handleCadastrarNovoCalcado() {
    const codigo = prompt("Digite o CÓDIGO do calçado (ex: TEN001):");
    if (!codigo) return;
    const modelo = prompt("Digite o MODELO/DESCRIÇÃO:");
    if (!modelo) return;
    const cor = prompt("Digite a COR:");
    if (!cor) return;
    const tamanho = prompt("Digite o TAMANHO (número):");
    if (!tamanho) return;
    const quantidade = prompt("Digite a QUANTIDADE inicial:");
    if (!quantidade) return;

    try {
        estoque.adicionarCalcado(codigo, modelo, cor, tamanho, quantidade);
        alert(`Calçado "${modelo}" (cód: ${codigo}) cadastrado com sucesso!`);
        exibirTodosCalcados(); 
    } catch (error) {
        alert("Erro ao cadastrar calçado: " + error.message);
    }
}