function adicionarQuantidadeAoCalcado(codigo) {
    const qtdeStr = prompt(`Quantos itens deseja adicionar ao calçado ${codigo}?`);
    const qtde = Number(qtdeStr);
    if (isNaN(qtde) || qtde <= 0) {
        alert("Quantidade inválida.");
        return;
    }
    try {
        estoque.adicionarQuantidadeAoEstoque(codigo, qtde);
        alert(`Nova quantidade para ${codigo}: ${estoque.consultarCalcadoPorCodigo(codigo).quantidade}`);
        exibirTodosCalcados();
    } catch (error) {
        alert("Erro: " + error.message);
    }
}